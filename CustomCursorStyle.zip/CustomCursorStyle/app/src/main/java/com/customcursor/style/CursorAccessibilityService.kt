package com.customcursor.style

import android.accessibilityservice.AccessibilityService
import android.content.SharedPreferences
import android.graphics.PixelFormat
import android.os.Build
import android.os.Handler
import android.os.Looper
import android.view.Gravity
import android.view.InputDevice
import android.view.MotionEvent
import android.view.WindowManager
import android.view.accessibility.AccessibilityEvent

// Só OBSERVA o mouse para saber onde ele está e desenha o cursor por cima.
// Não consome nenhum evento: os cliques continuam sendo os do mouse de verdade.
class CursorAccessibilityService : AccessibilityService() {

    private lateinit var wm: WindowManager
    private var view: OverlayCursorView? = null
    private var showing = true
    private val handler = Handler(Looper.getMainLooper())
    private val hideRunnable = Runnable { view?.hideCursor() }

    private val listener =
        SharedPreferences.OnSharedPreferenceChangeListener { _, _ -> applyConfig() }

    override fun onServiceConnected() {
        super.onServiceConnected()

        if (Build.VERSION.SDK_INT >= 34) {
            val info = serviceInfo
            info.motionEventSources = InputDevice.SOURCE_MOUSE
            serviceInfo = info
        }

        wm = getSystemService(WINDOW_SERVICE) as WindowManager
        val v = OverlayCursorView(this)
        view = v
        val lp = WindowManager.LayoutParams(
            WindowManager.LayoutParams.MATCH_PARENT,
            WindowManager.LayoutParams.MATCH_PARENT,
            WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE or
                WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or
                WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.START
            if (Build.VERSION.SDK_INT >= 30) {
                layoutInDisplayCutoutMode =
                    WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_ALWAYS
            }
        }
        wm.addView(v, lp)

        applyConfig()
        ConfigStore.prefs(this).registerOnSharedPreferenceChangeListener(listener)
    }

    private fun applyConfig() {
        val cfg = ConfigStore.load(this)
        showing = cfg.enabled
        val r = PointerRenderer.render(this, cfg)
        view?.setCursor(r.bitmap, r.hotX, r.hotY)
        if (!showing) view?.hideCursor()
    }

    // Chamado pelo sistema a cada movimento do mouse (Android 14+)
    override fun onMotionEvent(event: MotionEvent) {
        if (!showing) return
        if (!event.isFromSource(InputDevice.SOURCE_MOUSE)) return
        val v = view ?: return
        v.moveTo(event.rawX, event.rawY)
        handler.removeCallbacks(hideRunnable)
        handler.postDelayed(hideRunnable, 15000)
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {}
    override fun onInterrupt() {}

    override fun onDestroy() {
        handler.removeCallbacks(hideRunnable)
        ConfigStore.prefs(this).unregisterOnSharedPreferenceChangeListener(listener)
        view?.let { runCatching { wm.removeView(it) } }
        view = null
        super.onDestroy()
    }
}
