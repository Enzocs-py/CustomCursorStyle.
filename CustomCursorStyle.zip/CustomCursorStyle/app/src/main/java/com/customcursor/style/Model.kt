package com.customcursor.style

import android.content.Context
import android.content.SharedPreferences

enum class CursorShape(val label: String) {
    ARROW("Seta"),
    HAND("Mão"),
    CROSSHAIR("Mira"),
    CIRCLE("Círculo"),
    DIAMOND("Losango"),
    STAR("Estrela")
}

data class CursorConfig(
    val shape: CursorShape = CursorShape.ARROW,
    val sizeDp: Float = 32f,
    val fillColor: Int = 0xFFFFFFFF.toInt(),
    val borderColor: Int = 0xFF000000.toInt(),
    val borderThicknessDp: Float = 1.5f,
    val opacity: Float = 1f,
    val enabled: Boolean = true
)

object ConfigStore {
    fun prefs(c: Context): SharedPreferences =
        c.getSharedPreferences("pointer_cfg", Context.MODE_PRIVATE)

    fun load(c: Context): CursorConfig {
        val s = prefs(c)
        val d = CursorConfig()
        return CursorConfig(
            shape = runCatching { CursorShape.valueOf(s.getString("shape", d.shape.name)!!) }
                .getOrDefault(d.shape),
            sizeDp = s.getFloat("size", d.sizeDp),
            fillColor = s.getInt("fill", d.fillColor),
            borderColor = s.getInt("border", d.borderColor),
            borderThicknessDp = s.getFloat("thick", d.borderThicknessDp),
            opacity = s.getFloat("opacity", d.opacity),
            enabled = s.getBoolean("enabled", d.enabled)
        )
    }

    fun save(c: Context, cfg: CursorConfig) {
        prefs(c).edit()
            .putString("shape", cfg.shape.name)
            .putFloat("size", cfg.sizeDp)
            .putInt("fill", cfg.fillColor)
            .putInt("border", cfg.borderColor)
            .putFloat("thick", cfg.borderThicknessDp)
            .putFloat("opacity", cfg.opacity)
            .putBoolean("enabled", cfg.enabled)
            .apply()
    }
}
