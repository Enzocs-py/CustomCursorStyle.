package com.customcursor.style

import android.content.Context
import android.content.pm.PackageManager
import android.os.IBinder
import android.util.Log
import android.view.PointerIcon
import rikka.shizuku.Shizuku
import rikka.shizuku.ShizukuBinderWrapper
import rikka.shizuku.SystemServiceHelper

enum class ShizukuState { OFF, NO_PERMISSION, READY }

// Troca o ponteiro OFICIAL do mouse do Android usando o Shizuku.
// Não usa acessibilidade e não mexe nos cliques.
object ShizukuCursorHelper {
    private const val TAG = "ShizukuCursor"
    private const val REQ = 4101

    fun state(): ShizukuState {
        val running = runCatching { Shizuku.pingBinder() }.getOrDefault(false)
        if (!running) return ShizukuState.OFF
        val granted = runCatching {
            !Shizuku.isPreV11() && Shizuku.checkSelfPermission() == PackageManager.PERMISSION_GRANTED
        }.getOrDefault(false)
        return if (granted) ShizukuState.READY else ShizukuState.NO_PERMISSION
    }

    fun requestPermission(onResult: () -> Unit) {
        val l = object : Shizuku.OnRequestPermissionResultListener {
            override fun onRequestPermissionResult(requestCode: Int, grantResult: Int) {
                Shizuku.removeRequestPermissionResultListener(this)
                onResult()
            }
        }
        runCatching {
            Shizuku.addRequestPermissionResultListener(l)
            Shizuku.requestPermission(REQ)
        }
    }

    private fun setIcon(icon: PointerIcon?) {
        val binder: IBinder = ShizukuBinderWrapper(SystemServiceHelper.getSystemService("input"))
        val stub = Class.forName("android.hardware.input.IInputManager\$Stub")
        val im = stub.getMethod("asInterface", IBinder::class.java).invoke(null, binder)!!
        val iface = Class.forName("android.hardware.input.IInputManager")
        iface.getMethod("setCustomPointerIcon", PointerIcon::class.java).invoke(im, icon)
    }

    /** Retorna null se deu certo, ou a mensagem de erro. */
    fun applyConfig(ctx: Context, cfg: CursorConfig): String? {
        if (state() != ShizukuState.READY) return "Shizuku não está ativo ou sem permissão."
        return try {
            val r = PointerRenderer.render(ctx, cfg)
            setIcon(PointerIcon.create(r.bitmap, r.hotX, r.hotY))
            Log.i(TAG, "Ponteiro aplicado")
            null
        } catch (t: Throwable) {
            Log.e(TAG, "Falha ao aplicar", t)
            (t.cause ?: t).let { it.javaClass.simpleName + ": " + (it.message ?: "") }
        }
    }

    fun reset(): String? {
        if (state() != ShizukuState.READY) return "Shizuku não está ativo ou sem permissão."
        return try {
            setIcon(null)
            null
        } catch (t: Throwable) {
            Log.e(TAG, "Falha ao restaurar", t)
            (t.cause ?: t).let { it.javaClass.simpleName + ": " + (it.message ?: "") }
        }
    }
}
