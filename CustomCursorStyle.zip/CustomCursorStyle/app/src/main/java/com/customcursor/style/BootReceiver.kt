package com.customcursor.style

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import androidx.core.content.ContextCompat

class BootReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        if (ConfigStore.load(context).enabled) {
            ContextCompat.startForegroundService(context, Intent(context, PointerService::class.java))
        }
    }
}
