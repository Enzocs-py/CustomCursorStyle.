package com.customcursor.style

import android.app.Application
import android.os.Build
import org.lsposed.hiddenapibypass.HiddenApiBypass

class CursorApp : Application() {
    override fun onCreate() {
        super.onCreate()
        // Libera o acesso às APIs ocultas do Android (necessário para o IInputManager)
        runCatching {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.P) {
                HiddenApiBypass.addHiddenApiExemptions("L")
            }
        }
    }
}
