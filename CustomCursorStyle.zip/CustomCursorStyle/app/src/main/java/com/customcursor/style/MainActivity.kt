package com.customcursor.style

import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.provider.Settings
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.systemBarsPadding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Button
import androidx.compose.material3.FilterChip
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Slider
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp

private val palette: List<Int> = listOf(
    0xFFFFFFFF, 0xFF000000, 0xFFE53935, 0xFFFB8C00, 0xFFFDD835,
    0xFF43A047, 0xFF1E88E5, 0xFF8E24AA, 0xFFEC407A, 0xFF00ACC1
).map { it.toInt() }

fun isServiceEnabled(ctx: Context): Boolean {
    val enabled = Settings.Secure.getString(
        ctx.contentResolver, Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES
    ) ?: return false
    val cn = ComponentName(ctx, CursorAccessibilityService::class.java)
    return enabled.split(':').any {
        it.equals(cn.flattenToString(), true) || it.equals(cn.flattenToShortString(), true)
    }
}

class MainActivity : ComponentActivity() {
    private val resumes = mutableStateOf(0)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            MaterialTheme(colorScheme = lightColorScheme()) {
                Surface(Modifier.fillMaxSize()) { Screen(resumes.value) }
            }
        }
    }

    override fun onResume() {
        super.onResume()
        resumes.value = resumes.value + 1
    }
}

@Composable
fun Screen(refresh: Int) {
    val ctx = LocalContext.current
    var cfg by remember { mutableStateOf(ConfigStore.load(ctx)) }
    val serviceOn = remember(refresh) { isServiceEnabled(ctx) }
    val preview = remember(cfg) { PointerRenderer.render(ctx, cfg).bitmap.asImageBitmap() }

    fun update(n: CursorConfig) {
        cfg = n
        ConfigStore.save(ctx, n)
    }

    Column(
        Modifier
            .systemBarsPadding()
            .verticalScroll(rememberScrollState())
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(8.dp)
    ) {
        Text("Custom Cursor Style", style = MaterialTheme.typography.headlineSmall)
        Text("Desenha um cursor personalizado sobre a tela, seguindo o mouse. Os cliques continuam sendo os do mouse de verdade.")

        Text(
            if (serviceOn) "Serviço de acessibilidade: ligado ✓"
            else "Serviço de acessibilidade: desligado. Toque abaixo, abra \"Custom Cursor Style\" e ative.",
            style = MaterialTheme.typography.titleSmall
        )
        Button(onClick = {
            ctx.startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
        }) { Text("Abrir Acessibilidade") }

        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(12.dp)) {
            Switch(checked = cfg.enabled, onCheckedChange = { update(cfg.copy(enabled = it)) })
            Text("Mostrar cursor personalizado")
        }

        // Pré-visualização (tamanho real)
        Box(
            Modifier
                .fillMaxWidth()
                .height(140.dp)
                .background(Color(0xFFE0E0E0)),
            contentAlignment = Alignment.Center
        ) {
            Image(bitmap = preview, contentDescription = null)
        }

        Text("Formato", style = MaterialTheme.typography.titleSmall)
        Row(
            Modifier.horizontalScroll(rememberScrollState()),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            CursorShape.values().forEach { s ->
                FilterChip(
                    selected = cfg.shape == s,
                    onClick = { update(cfg.copy(shape = s)) },
                    label = { Text(s.label) }
                )
            }
        }

        Text("Tamanho: ${cfg.sizeDp.toInt()} dp")
        Slider(value = cfg.sizeDp, onValueChange = { update(cfg.copy(sizeDp = it)) }, valueRange = 16f..96f)

        Text("Opacidade: ${(cfg.opacity * 100).toInt()}%")
        Slider(value = cfg.opacity, onValueChange = { update(cfg.copy(opacity = it)) }, valueRange = 0.2f..1f)

        Text("Espessura da borda: ${"%.1f".format(cfg.borderThicknessDp)} dp")
        Slider(
            value = cfg.borderThicknessDp,
            onValueChange = { update(cfg.copy(borderThicknessDp = it)) },
            valueRange = 0f..6f
        )

        ColorRow("Cor de preenchimento", cfg.fillColor) { update(cfg.copy(fillColor = it)) }
        ColorRow("Cor da borda", cfg.borderColor) { update(cfg.copy(borderColor = it)) }

        Text(
            "Obs.: a seta original do Android continua existindo por baixo. Um tamanho maior ajuda a cobri-la.",
            style = MaterialTheme.typography.bodySmall
        )
    }
}

@Composable
fun ColorRow(title: String, selected: Int, onPick: (Int) -> Unit) {
    Text(title, style = MaterialTheme.typography.titleSmall)
    Row(
        Modifier
            .horizontalScroll(rememberScrollState())
            .padding(vertical = 6.dp),
        horizontalArrangement = Arrangement.spacedBy(8.dp)
    ) {
        palette.forEach { c ->
            val sel = c == selected
            Box(
                Modifier
                    .size(36.dp)
                    .clip(CircleShape)
                    .background(Color(c))
                    .border(
                        if (sel) 3.dp else 1.dp,
                        if (sel) MaterialTheme.colorScheme.primary else Color.Gray,
                        CircleShape
                    )
                    .clickable { onPick(c) }
            )
        }
    }
}
