package com.customcursor.style

import android.content.Intent
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.systemBarsPadding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Button
import androidx.compose.material3.FilterChip
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Slider
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.core.content.ContextCompat

private val palette: List<Int> = listOf(
    0xFFFFFFFF, 0xFF000000, 0xFFE53935, 0xFFFB8C00, 0xFFFDD835,
    0xFF43A047, 0xFF1E88E5, 0xFF8E24AA, 0xFFEC407A, 0xFF00ACC1
).map { it.toInt() }

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            MaterialTheme(colorScheme = lightColorScheme()) {
                Surface(Modifier.fillMaxSize()) { Screen() }
            }
        }
    }
}

@Composable
fun Screen() {
    val ctx = LocalContext.current
    var cfg by remember { mutableStateOf(ConfigStore.load(ctx)) }
    var shizuku by remember { mutableStateOf(ShizukuCursorHelper.state()) }
    var message by remember { mutableStateOf("") }
    val preview = remember(cfg) { PointerRenderer.render(ctx, cfg).bitmap.asImageBitmap() }

    Column(
        Modifier
            .systemBarsPadding()
            .verticalScroll(rememberScrollState())
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(8.dp)
    ) {
        Text("Custom Cursor Style", style = MaterialTheme.typography.headlineSmall)
        Text("Muda só o visual do ponteiro oficial do mouse. Não mexe nos cliques.")

        // Status do Shizuku
        Text(
            when (shizuku) {
                ShizukuState.OFF -> "Shizuku: desligado. Abra o app Shizuku e inicie o serviço."
                ShizukuState.NO_PERMISSION -> "Shizuku: ativo, falta dar permissão a este app."
                ShizukuState.READY -> "Shizuku: pronto ✓"
            },
            style = MaterialTheme.typography.titleSmall
        )
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            OutlinedButton(onClick = { shizuku = ShizukuCursorHelper.state() }) { Text("Verificar") }
            if (shizuku == ShizukuState.NO_PERMISSION) {
                Button(onClick = {
                    ShizukuCursorHelper.requestPermission { shizuku = ShizukuCursorHelper.state() }
                }) { Text("Dar permissão") }
            }
        }

        // Pré-visualização (tamanho real)
        Box(
            Modifier
                .fillMaxWidth()
                .height(140.dp)
                .background(Color(0xFFE0E0E0)),
            contentAlignment = Alignment.Center
        ) {
            Image(bitmap = preview, contentDescription = null)
        }

        // Formato
        Text("Formato", style = MaterialTheme.typography.titleSmall)
        Row(
            Modifier.horizontalScroll(rememberScrollState()),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            CursorShape.values().forEach { s ->
                FilterChip(
                    selected = cfg.shape == s,
                    onClick = { cfg = cfg.copy(shape = s) },
                    label = { Text(s.label) }
                )
            }
        }

        Text("Tamanho: ${cfg.sizeDp.toInt()} dp")
        Slider(value = cfg.sizeDp, onValueChange = { cfg = cfg.copy(sizeDp = it) }, valueRange = 16f..96f)

        Text("Opacidade: ${(cfg.opacity * 100).toInt()}%")
        Slider(value = cfg.opacity, onValueChange = { cfg = cfg.copy(opacity = it) }, valueRange = 0.2f..1f)

        Text("Espessura da borda: ${"%.1f".format(cfg.borderThicknessDp)} dp")
        Slider(
            value = cfg.borderThicknessDp,
            onValueChange = { cfg = cfg.copy(borderThicknessDp = it) },
            valueRange = 0f..6f
        )

        ColorRow("Cor de preenchimento", cfg.fillColor) { cfg = cfg.copy(fillColor = it) }
        ColorRow("Cor da borda", cfg.borderColor) { cfg = cfg.copy(borderColor = it) }

        Spacer(Modifier.height(4.dp))
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            Button(onClick = {
                cfg = cfg.copy(enabled = true)
                ConfigStore.save(ctx, cfg)
                ContextCompat.startForegroundService(ctx, Intent(ctx, PointerService::class.java))
                shizuku = ShizukuCursorHelper.state()
                message = ShizukuCursorHelper.applyConfig(ctx, cfg) ?: "Aplicado! Mexa o mouse para ver."
            }) { Text("Aplicar") }

            OutlinedButton(onClick = {
                cfg = cfg.copy(enabled = false)
                ConfigStore.save(ctx, cfg)
                ctx.stopService(Intent(ctx, PointerService::class.java))
                shizuku = ShizukuCursorHelper.state()
                message = ShizukuCursorHelper.reset() ?: "Ponteiro padrão restaurado."
            }) { Text("Restaurar padrão") }
        }
        if (message.isNotEmpty()) Text(message, style = MaterialTheme.typography.bodyMedium)
        Text(if (cfg.enabled) "Estado: ativo" else "Estado: inativo", style = MaterialTheme.typography.labelMedium)
    }
}

@Composable
fun ColorRow(title: String, selected: Int, onPick: (Int) -> Unit) {
    Text(title, style = MaterialTheme.typography.titleSmall)
    Row(
        Modifier
            .horizontalScroll(rememberScrollState())
            .padding(vertical = 6.dp),
        horizontalArrangement = Arrangement.spacedBy(8.dp)
    ) {
        palette.forEach { c ->
            val sel = c == selected
            Box(
                Modifier
                    .size(36.dp)
                    .clip(CircleShape)
                    .background(Color(c))
                    .border(
                        if (sel) 3.dp else 1.dp,
                        if (sel) MaterialTheme.colorScheme.primary else Color.Gray,
                        CircleShape
                    )
                    .clickable { onPick(c) }
            )
        }
    }
}
