package com.customcursor.style

import android.content.Context
import android.graphics.Bitmap
import android.graphics.Canvas
import android.view.View

// Tela cheia, transparente, que só desenha o cursor na posição do mouse.
class OverlayCursorView(ctx: Context) : View(ctx) {
    private var bmp: Bitmap? = null
    private var hotX = 0f
    private var hotY = 0f
    private var posX = 0f
    private var posY = 0f
    private var shown = false
    private val loc = IntArray(2)

    fun setCursor(b: Bitmap, hx: Float, hy: Float) {
        bmp = b; hotX = hx; hotY = hy
        invalidate()
    }

    fun moveTo(x: Float, y: Float) {
        posX = x; posY = y; shown = true
        invalidate()
    }

    fun hideCursor() {
        shown = false
        invalidate()
    }

    override fun onDraw(canvas: Canvas) {
        val b = bmp ?: return
        if (!shown) return
        getLocationOnScreen(loc)
        canvas.drawBitmap(b, posX - loc[0] - hotX, posY - loc[1] - hotY, null)
    }
}
