package com.customcursor.style

import android.content.Context
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Path
import android.graphics.RectF
import kotlin.math.cos
import kotlin.math.sin

data class Rendered(val bitmap: Bitmap, val hotX: Float, val hotY: Float)

// Desenha o ponteiro em um Bitmap. "hot" é o ponto exato que clica.
object PointerRenderer {

    private fun withOpacity(color: Int, op: Float): Int = Color.argb(
        (Color.alpha(color) * op.coerceIn(0f, 1f)).toInt(),
        Color.red(color), Color.green(color), Color.blue(color)
    )

    fun render(ctx: Context, cfg: CursorConfig): Rendered {
        val d = ctx.resources.displayMetrics.density
        val s = (cfg.sizeDp * d).toInt().coerceIn(24, 256)
        val bmp = Bitmap.createBitmap(s, s, Bitmap.Config.ARGB_8888)
        val c = Canvas(bmp)

        val bw = cfg.borderThicknessDp * d
        val pad = bw / 2f + 1f
        val w = s - 2 * pad
        fun x(u: Float) = pad + u * w
        fun y(v: Float) = pad + v * w

        val fill = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            style = Paint.Style.FILL
            color = withOpacity(cfg.fillColor, cfg.opacity)
        }
        val line = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            style = Paint.Style.STROKE
            strokeWidth = bw
            strokeJoin = Paint.Join.ROUND
            color = withOpacity(cfg.borderColor, cfg.opacity)
        }
        fun draw(p: Path) {
            c.drawPath(p, fill)
            if (bw > 0f) c.drawPath(p, line)
        }

        var hx = s / 2f
        var hy = s / 2f

        when (cfg.shape) {
            CursorShape.ARROW -> {
                val p = Path()
                p.moveTo(x(0f), y(0f))
                p.lineTo(x(0f), y(0.85f))
                p.lineTo(x(0.22f), y(0.66f))
                p.lineTo(x(0.36f), y(0.98f))
                p.lineTo(x(0.5f), y(0.92f))
                p.lineTo(x(0.37f), y(0.62f))
                p.lineTo(x(0.66f), y(0.62f))
                p.close()
                draw(p)
                hx = x(0f); hy = y(0f)
            }
            CursorShape.HAND -> {
                fun rr(l: Float, t: Float, r: Float, b: Float, rad: Float): Path =
                    Path().apply {
                        addRoundRect(RectF(x(l), y(t), x(r), y(b)), rad * w, rad * w, Path.Direction.CW)
                    }
                val p = Path()
                p.op(rr(0.26f, 0.00f, 0.44f, 0.62f, 0.09f), Path.Op.UNION)
                p.op(rr(0.44f, 0.26f, 0.58f, 0.62f, 0.07f), Path.Op.UNION)
                p.op(rr(0.58f, 0.30f, 0.72f, 0.64f, 0.07f), Path.Op.UNION)
                p.op(rr(0.72f, 0.38f, 0.86f, 0.68f, 0.07f), Path.Op.UNION)
                p.op(rr(0.26f, 0.50f, 0.86f, 0.98f, 0.14f), Path.Op.UNION)
                p.op(rr(0.08f, 0.46f, 0.30f, 0.74f, 0.09f), Path.Op.UNION)
                draw(p)
                hx = x(0.35f); hy = y(0.02f)
            }
            CursorShape.CROSSHAIR -> {
                val lw = w * 0.12f
                val outer = Paint(line).apply { strokeWidth = lw + 2 * bw; strokeCap = Paint.Cap.BUTT }
                val inner = Paint(fill).apply {
                    style = Paint.Style.STROKE; strokeWidth = lw; strokeCap = Paint.Cap.BUTT
                }
                if (bw > 0f) {
                    c.drawLine(x(0f), y(0.5f), x(1f), y(0.5f), outer)
                    c.drawLine(x(0.5f), y(0f), x(0.5f), y(1f), outer)
                }
                c.drawLine(x(0f), y(0.5f), x(1f), y(0.5f), inner)
                c.drawLine(x(0.5f), y(0f), x(0.5f), y(1f), inner)
            }
            CursorShape.CIRCLE -> {
                c.drawCircle(s / 2f, s / 2f, w / 2f, fill)
                if (bw > 0f) c.drawCircle(s / 2f, s / 2f, w / 2f, line)
            }
            CursorShape.DIAMOND -> {
                val p = Path()
                p.moveTo(s / 2f, y(0f))
                p.lineTo(x(1f), s / 2f)
                p.lineTo(s / 2f, y(1f))
                p.lineTo(x(0f), s / 2f)
                p.close()
                draw(p)
            }
            CursorShape.STAR -> {
                val p = Path()
                val cx = s / 2f
                val cy = s / 2f + w * 0.03f
                val ro = w / 2f
                val ri = ro * 0.42f
                for (i in 0 until 10) {
                    val r = if (i % 2 == 0) ro else ri
                    val a = Math.toRadians((-90 + i * 36).toDouble())
                    val px = cx + (r * cos(a)).toFloat()
                    val py = cy + (r * sin(a)).toFloat()
                    if (i == 0) p.moveTo(px, py) else p.lineTo(px, py)
                }
                p.close()
                draw(p)
            }
        }
        return Rendered(bmp, hx.coerceIn(0f, s - 1f), hy.coerceIn(0f, s - 1f))
    }
}
